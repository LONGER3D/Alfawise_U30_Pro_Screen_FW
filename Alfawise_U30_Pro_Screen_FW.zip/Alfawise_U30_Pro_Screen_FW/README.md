# Alfawise_U30_Pro_Screen_FW

This is the screen UI of Alfawise U30_Pro. It was written by LONGER.

## Screen_software_guide

This folder includes screen development software and development documentation.

You can use screen development software to add features to your printer. But you must first read the development documentation carefully.

## U30_Pro_UI_FW

This folder includes screen UI firmware and motherboard firmware.

If you want to reset your machine to factory settings, you can use them.

For how to download the UI to the screen, you can carefully read the SD Interface on the tenth page of the development document.

## Alfawise_U30_Pro_Screen_Project

This folder includes U30_Pro Screen UI source code. 



